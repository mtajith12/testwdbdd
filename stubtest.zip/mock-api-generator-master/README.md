# mock-api-generator

This app creates mock apis on based on the JSON files and returns matching responses.

# How to use 
Commit the json files to to a project specfic directory (e.g. /static/DSS/ ) inside resources folder and set the property to the folder path
mockapi.json.folder: /static/DSS/

This App searches all the json files from mockapi.json.folder and creates resective apis 

# JSON Structure
Json structure contains 3 imports sections
## apiDetails
Set Mock API URL and method in this section 
e.g.
```
"apiDetails": {
  "URL": "/accounts/{key}/restraints",
  "METHOD": "POST"
}
```
## mockData

### matcher
Matcher will have all the matching details that are used to match a request to response
Currently this App matches based on path, query,header or body ( all these are optional.. set these values as needed)

e.g.
```
 "matcher": {
  "path": {"z": "100"},
  "query": { "test1": "123", "test2": "1234" },
  "header": { "host": "localhost:8080" },
  "body": { "$['tes1'][0]['array']": "1" , "$['tes1'][0]['boolean']": "true" }
 },
```        

for body, input the vlues in json path format
e.g.
```
"body": { "$['tes1'][0]['array']": "1" , "$['tes1'][0]['boolean']": "true" }

```
this matches test1[0].array == 1 and test1[0].boolean == true for below request

```
{
"tes1":[
	{ "array": 1, "boolean": false
	},
	{ "array": "2", "boolean": "true"
	}
]
}
```
Note: All matches does sting based comparision 


### response\responseLoop

If match is successful, mock API returns respective response
api response status = httpStatus
    response body = body
```
 "response": {
  "httpStatus": 200,
  "body": { "test": "123", "test2": "1234" }
  }  
```  

Use responseLoop, if differnct responses are excpected in loop

Response can be generated based on request data.
e.g.
```
"response": {
  "httpStatus": 200,
  "body": {
    "hello2": [
      { "hello4": "@@header.test2::defaultHeader" },
      { "hello5": "@@query.test1::defaultQuery" },
      { "hello6": "@@path.path1::defaultPath" },
      { "hello6": "@@body.$['tes1'][0]['array']::defaultBody" }
    ]
  }
}
```	
 to generate response based on request data ,set response proepry in the format ( e.g. above)
 "@@header|query|path|body.{request-property-name}::defaultValueIfProperyNotpresent in request"
 
 Note: body should be represented in JSON path format
