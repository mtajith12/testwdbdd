package com.anz.oacb.mockapi.dssmockapi;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

import java.io.IOException;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.anz.oacb.mockapi.dssmockapi.controller.MockApiController;
import com.anz.oacb.mockapi.dssmockapi.service.MockApiService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

@RunWith(SpringRunner.class)
public class MockApiControllerTest {
    @InjectMocks
    private MockApiController mockApiController;
    @Autowired
    private ResourcePatternResolver resourcePatternResolver;
    @Mock
    private RequestMappingHandlerMapping requestMappingHandlerMapping;
    @Mock
    private MockApiService mockApiService;

    @Test
    public void testInit() throws IOException, NoSuchMethodException {
        Resource[] resource = resourcePatternResolver.getResources("classpath:testfiles/*.json");
        given(mockApiService.getApiResources()).willReturn(resource);
        mockApiController.init();
    }

    @Test
    public void testGetApiRequestHandler() throws IOException {
        JsonNode response = new ObjectNode(JsonNodeFactory.instance).set("httpStatus", new TextNode("400"));
        given(mockApiService.readRequestDetails(any())).willReturn(new HashMap<>());
        given(mockApiService.matchApi(any())).willReturn(response);
        mockApiController.getApiRequestHandler(any());
    }

    @Test
    public void testGetApiRequestHandlerException() throws IOException {
        given(mockApiService.readRequestDetails(any())).willReturn(new HashMap<>());
        given(mockApiService.matchApi(any())).willThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
        mockApiController.getApiRequestHandler(any());
    }
}
