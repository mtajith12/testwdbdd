package com.anz.oacb.mockapi.dssmockapi;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.catalina.util.ParameterMap;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;

import com.anz.oacb.mockapi.dssmockapi.service.MockApiService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@TestPropertySource(properties = {"mockapi.json.folder=/testfiles"})
public class MockApiServiceTest {
    @InjectMocks
    private MockApiService mockApiService;
    @Mock
    private ResourcePatternResolver resourcePatternResolver;
    @Test
    public void getApiResourcesTest() throws IOException {
        Assertions.assertThat(mockApiService.getApiResources()).isNull();
    }

    @Test
    public void readRequestDetailsTest() throws IOException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("testHeader","testHeaderVal");
        request.addParameter("testParam","testParamVal");
        request.setRequestURI("testURI");
        request.setMethod("POST");
        Map<String, Object> requestMap =  mockApiService.readRequestDetails(request);
        Assertions.assertThat(requestMap).isNotNull();
    }

    @Test
    public void matchApiTest() throws IOException {
        Resource resource = new ClassPathResource("testfiles/test.json");
        given(resourcePatternResolver.getResources(any())).willReturn(new Resource[]{resource});
        Map<String, Object> requestDetails = prepareRequestDetails
                ("/test/mockdata", "POST", "",new HashMap<>(), new LinkedHashMap<>(), new ParameterMap<>());

        JsonNode response =  mockApiService.matchApi(requestDetails);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.get("httpStatus").toString()).isEqualTo("200");

        String body = "{\"tes1\":[{ \"array\": 1, \"booln\": true}]}";

        Map<String, List<String>> headers = new HashMap<>() {{
            put("host", Collections.singletonList("localhost:8080"));
        }};
        Map<String, String> pathParam = new LinkedHashMap<>() {{
            put("z", "100");
        }};
        ParameterMap<String, String[]> queryParams = new ParameterMap<>();
        queryParams.put("test1", new String[]{"123"});
        queryParams.put("test2", new String[]{"1234"});
        Map<String, Object> requestDetails2 = prepareRequestDetails
                ("/x/y/100/parametrizedHandler", "POST", body, headers, pathParam, queryParams);

        JsonNode response2 =  mockApiService.matchApi(requestDetails2);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response2.get("httpStatus").toString()).isEqualTo("200");
        Assertions.assertThat(response2.get("body").toString()).isEqualTo("{\"test\":\"123\",\"test2\":\"1234\"}");

    }

    @Test
    public void matchApiTestResponseLoop() throws IOException {
        Resource resource = new ClassPathResource("testfiles/test.json");
        given(resourcePatternResolver.getResources(any())).willReturn(new Resource[]{resource});
        Map<String, Object> requestDetails = prepareRequestDetails
                ("/test/responseloop", "POST", "",new HashMap<>(), new LinkedHashMap(), new ParameterMap<>());

        JsonNode response =  mockApiService.matchApi(requestDetails);
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.get("httpStatus").toString()).isEqualTo("503");
        Map<String, Object> requestDetails2 = prepareRequestDetails
                ("/test/responseloop", "POST", "",new HashMap<>(), new LinkedHashMap<>(), new ParameterMap<>());
        JsonNode response2 =  mockApiService.matchApi(requestDetails2);

        Assertions.assertThat(response2.get("httpStatus").toString()).isEqualTo("504");

    }

    @Test(expected = HttpClientErrorException.class )
    public void matchApiTestException() throws IOException {
        Resource resource = new ClassPathResource("testfiles/test.json");
        given(resourcePatternResolver.getResources(any())).willReturn(new Resource[]{resource});
        Map<String, Object> requestDetails = prepareRequestDetails
                ("/test/responseloop123", "POST", "",new HashMap<>(), new LinkedHashMap<>(), new ParameterMap<>());
        mockApiService.matchApi(requestDetails);

    }

    @Test
    public void mapResponseTest() throws IOException {
        String body = "{\"tes1\":[{ \"array\": 1, \"booln\": true}]}";

        Map<String, List<String>> headers = new HashMap<>() {{
            put("test2", Collections.singletonList("localhost:8080"));
        }};
        ParameterMap<String, String[]> queryParams = new ParameterMap<>();
        queryParams.put("path1", new String[]{"123"});
        Map<String, Object> requestDetails = prepareRequestDetails
                ("/x/y/100/parametrizedHandler", "POST", body, headers, new LinkedHashMap<>(), queryParams);

        String response = mockApiService.mapResponse(getResponseNode(), requestDetails);

        Assertions.assertThat(response).isEqualTo("{\"hello\":\"prop\",\"hello2\":[{\"hello4\":\"localhost:8080\"},{\"hello5\":\"123\"},{\"hello6\":1}]}");

        Map<String, Object> requestDetails2 = prepareRequestDetails
                ("/x/y/100/parametrizedHandler", "POST", "", new HashMap<>(), new LinkedHashMap<>(), new ParameterMap<>());

        String response2 = mockApiService.mapResponse(getResponseNode(), requestDetails2);

        Assertions.assertThat(response2).isEqualTo("{\"hello\":\"prop\",\"hello2\":[{\"hello4\":\"defaultHeader\"},{\"hello5\":\"defaultQuery\"},{\"hello6\":\"defaultBody\"}]}");

    }

    private JsonNode getResponseNode() throws IOException{
        String responseString = " {\"httpStatus\": 200, \"body\": {\"hello\": \"prop\",\"hello2\": [{ \"hello4\": \"@@header.test2::defaultHeader\" },{ \"hello5\": \"@@query.path1::defaultQuery\" },{ \"hello6\": \"@@body.$['tes1'][0]['array']::defaultBody\" }]}}";
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readTree(responseString);
    }

    private Map<String, Object> prepareRequestDetails(
            String url, String method, String body, Map headers,  Map pathParams,ParameterMap queryParams
            ){
        Map<String, Object> requestDetails = new HashMap<>();
        requestDetails.put("requestURI",url);
        requestDetails.put("method",method);
        requestDetails.put("requestBody",body);
        requestDetails.put("headers", headers);
        requestDetails.put("queryParams", queryParams);
        requestDetails.put("pathParams",pathParams);
        return requestDetails;
    }

}
