package com.anz.oacb.mockapi.dssmockapi.controller;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.anz.oacb.mockapi.dssmockapi.service.MockApiService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONArray;

@RestController
@Slf4j
@RequiredArgsConstructor
public class MockApiController {

    private final RequestMappingHandlerMapping handlerMapping;
    private final MockApiService mockApiService;
    private ObjectMapper  objectMapper = new ObjectMapper();

    @PostConstruct
    public void init() throws IOException, NoSuchMethodException {
        generateGetAPIs();
    }

     public ResponseEntity getApiRequestHandler(HttpServletRequest servletRequest) throws IOException {
         var requestDetails = mockApiService.readRequestDetails(servletRequest);
         try{
             var responseMap = mockApiService.matchApi(requestDetails);
             var httpStatus =  responseMap.get("httpStatus").asInt();
             String responseBody =  mockApiService.mapResponse(responseMap, requestDetails);
             log.info("Returning Response :: Http Status: {}, Response: {} ", httpStatus, responseBody);
             return ResponseEntity.status(httpStatus).body(responseBody);
         }catch (HttpClientErrorException ex){
             log.error("Http Status: {}, Error: {} ", ex.getStatusCode(), ex.getStatusText());
             return ResponseEntity.status(ex.getStatusCode()).body(objectMapper.writeValueAsString(ex.getStatusText()));
         }

    }

    private void generateGetAPIs() throws IOException, NoSuchMethodException {
        var resources = mockApiService.getApiResources();
        for( Resource resource: resources){
            log.info("Reading Resource  : {}", resource.getFilename());
            var reader = new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8);
            var fileAsSting = FileCopyUtils.copyToString(reader);
            JSONArray apiDetails = JsonPath.parse(fileAsSting).read("$[*]['apiDetails']");
            for(var apiDetail: apiDetails){
                var  apiDetailMap = (LinkedHashMap<String, String>) apiDetail;
                registerApiMapping(apiDetailMap.get("URL"), apiDetailMap.get("METHOD"));
            }
        }
    }

    private void registerApiMapping(String apiUrl, String apiMethod) throws NoSuchMethodException {
        handlerMapping.registerMapping(
                RequestMappingInfo.paths(apiUrl)
                        .methods(RequestMethod.valueOf(apiMethod))
                        .produces(MediaType.APPLICATION_JSON_VALUE)
                        .headers("Accept=*/*").build(),
                this,
                MockApiController.class.getDeclaredMethod("getApiRequestHandler", HttpServletRequest.class));

        log.info("Creating API for Method : {} , URL : {}", apiMethod , apiUrl);
    }
}
