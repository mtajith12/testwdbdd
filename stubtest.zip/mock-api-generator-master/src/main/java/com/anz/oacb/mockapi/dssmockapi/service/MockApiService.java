package com.anz.oacb.mockapi.dssmockapi.service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.util.ParameterMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.HandlerMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.BooleanNode;
import com.fasterxml.jackson.databind.node.NumericNode;
import com.fasterxml.jackson.databind.node.TextNode;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.google.common.collect.Maps;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.PathNotFoundException;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONArray;

@Service
@Slf4j
@RequiredArgsConstructor
public class MockApiService {

    private static final String REQUEST_URI = "requestURI";
    private static final String HEADERS = "headers";
    private static final String PATH_PARAMS = "pathParams";
    private static final String QUERY_PARAMS = "queryParams";
    private static final String METHOD = "method";

    @Value("${mockapi.json.folder:/static/DSS/}")
    private String mockApiJsonFolder;

    private final ResourcePatternResolver resourcePatternResolver;
    private ObjectMapper objectMapper = new ObjectMapper();
    private static final Map<String, Integer> REQUEST_CACHE = new HashMap<>();

    public Map<String, Object> readRequestDetails(HttpServletRequest servletRequest) throws IOException {
        Map<String, Object> requestDetails = Maps.newHashMap();
        var headers = Collections.list(servletRequest.getHeaderNames())
                .stream()
                .collect(Collectors.toMap(Function.identity(),h -> Collections.list(servletRequest.getHeaders(h))));
        var pathParams =
                (LinkedHashMap<String, String>)servletRequest.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);

        var requestBody = servletRequest.getReader().lines().collect(Collectors.joining());

        log.info("API Request Received for  {} : {} ", servletRequest.getMethod(), servletRequest.getRequestURI());
        log.info("QUERY Params: {} ", mapToString(servletRequest.getParameterMap()) );
        log.info("PATH Params: {} ", pathParams );
        log.info("Headers: {} ", headers);
        log.info("Body: {} ", requestBody);

        requestDetails.put(HEADERS,headers);
        requestDetails.put(REQUEST_URI,servletRequest.getRequestURI());
        requestDetails.put(QUERY_PARAMS,servletRequest.getParameterMap());
        requestDetails.put(PATH_PARAMS,pathParams);
        requestDetails.put(METHOD,servletRequest.getMethod());
        requestDetails.put("requestBody",requestBody);

        return requestDetails;
    }

    public JsonNode matchApi(Map<String, Object> requestDetails ) throws IOException {
        var queryParams = (ParameterMap<String, String[]>)requestDetails.get(QUERY_PARAMS);
        var headers = (Map<String, List<String>>)requestDetails.get(HEADERS);
        var requestBody = (String)requestDetails.get("requestBody");
        var requestPathParams = (LinkedHashMap<String, String>)requestDetails.get(PATH_PARAMS);

        for (var resource : getApiResources()) {
            var jsonAsSting = FileCopyUtils.copyToString(
                    new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8));
            JSONArray allApis = JsonPath.parse(jsonAsSting).read("$[*]");
            for(Object api: allApis) {
                var apiMap = (LinkedHashMap) api;
                var apiDetails = (LinkedHashMap) apiMap.get("apiDetails");
                JSONArray allmockData = (JSONArray) apiMap.get("mockData");
                for (Object mockData : allmockData) {
                    var mockDataString = objectMapper.writeValueAsString(mockData);
                    var pathJson =  readJsonPath(mockDataString, "$['matcher']['path']");
                    var queryJson =  readJsonPath(mockDataString, "$['matcher']['query']");
                    var headerJson =  readJsonPath(mockDataString, "$['matcher']['header']");
                    var bodyJson =  readJsonPath(mockDataString, "$['matcher']['body']");

                    boolean pathMatch ;
                    boolean queryMatch ;
                    boolean headerMatch ;
                    boolean bodyMatch ;
                    if(null != pathJson){
                        var pathParams = (LinkedHashMap<String, String>)pathJson;
                        pathMatch = requestDetails.get(METHOD).equals(apiDetails.get("METHOD"))
                                && requestDetails.get(REQUEST_URI).equals(pathResolve(apiDetails.get("URL").toString(), pathParams, requestPathParams));
                    }else {
                        pathMatch = apiDetails.get("URL").equals(requestDetails.get(REQUEST_URI));
                    }
                    if(pathMatch && null != queryJson){
                        var queryMatcher = (LinkedHashMap<String, String>) queryJson;
                        queryMatch = queryMatcher.entrySet().stream().allMatch(entry ->
                                queryParams.containsKey(entry.getKey()) &&
                                        Arrays.stream(queryParams.get(entry.getKey()))
                                                .anyMatch(entry.getValue()::equals));
                    }else{
                        queryMatch =true;
                    }
                    if(queryMatch && null != headerJson){
                        var headerMatcher = (LinkedHashMap<String, String>) headerJson;
                        headerMatch = headerMatcher.entrySet().stream().allMatch(entry ->
                                headers.containsKey(entry.getKey()) &&
                                        headers.get(entry.getKey()).stream()
                                                .anyMatch(entry.getValue()::equals));
                    }else{
                        headerMatch = true;
                    }
                    if(headerMatch && null != bodyJson && !StringUtils.isEmpty(requestBody)){
                        LinkedHashMap<String, String> bodyMatcher = (LinkedHashMap<String, String>) bodyJson;
                        bodyMatch = bodyMatcher.entrySet().stream().allMatch(entry ->{
                            var nodes = readJSONArray(requestBody, entry.getKey());
                            if( null != nodes){
                                Iterator<JsonNode> jsonNodeIterator = nodes.elements();
                                while(jsonNodeIterator.hasNext()){
                                    Object jsonVal =jsonNodeIterator.next();
                                    if( ((jsonVal instanceof BooleanNode) && jsonVal.toString().equals(entry.getValue()))
                                        || ((jsonVal instanceof NumericNode) && jsonVal.toString().equals(entry.getValue()))
                                        || ((jsonVal instanceof TextNode)
                                            && jsonVal.toString().equals("\""+entry.getValue()+"\"")))
                                        return true;
                                }
                            }
                            return false;
                        });
                    }else{
                        bodyMatch =true;
                    }
                    if (pathMatch && queryMatch && headerMatch && bodyMatch) {
                        log.info("API Match Successful for : {} ", mockDataString);
                        var responseLoop = readJSONArray(mockDataString,"$['responseLoop']");
                        if(responseLoop != null) {
                            return readResponse(responseLoop , apiDetails.get("URL").toString(),mockDataString );
                        }else {
                            var response = readJSONArray(mockDataString,"$['response']");
                            if(response == null){
                                throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "response section is missing");
                            }
                            return response.get(0);
                        }
                     }
                }
            }
        }
        throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "No Matching API Found for this request");
    }

    public Resource[] getApiResources() throws IOException {
        return resourcePatternResolver.getResources("classpath:"+ mockApiJsonFolder +"/*.json");

    }

    public String mapResponse(JsonNode responseMap, Map<String, Object> requestDetails) throws JsonProcessingException {
        if(responseMap.get("body") != null){
            var queryParams = (ParameterMap<String, String[]>)requestDetails.get(QUERY_PARAMS);
            var headers = (Map<String, List<String>>)requestDetails.get(HEADERS);
            var requestBody = (String)requestDetails.get("requestBody");
            var pathParams = (LinkedHashMap<String, String>)requestDetails.get(PATH_PARAMS);

            String response =  objectMapper.writeValueAsString(responseMap.get("body"));

            Map<String, Object> flattenMap = new JsonFlattener(response)
                    .withKeyTransformer((key) -> "['"+key+"']").flattenAsMap();
            Map<String, Object> filteredMap = flattenMap.entrySet().stream()
                    .filter(entry -> entry.getValue().toString().startsWith("@@"))
                    .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));

            for(Map.Entry<String, Object> entry: filteredMap.entrySet()) {
                String entryVal= entry.getValue().toString();
                String headerKey = getEntrySearchKey(entryVal, "@@header.");
                String queryKey = getEntrySearchKey(entryVal, "@@query.");
                String pathKey = getEntrySearchKey(entryVal, "@@path.");
                String bodyKey = getEntrySearchKey(entryVal, "@@body.");
                if(null != headerKey)
                    response = response.replace(entryVal,
                            null != headers.get(headerKey)
                                    ? headers.get(headerKey).get(0)
                                    : getDefaultVal(entryVal));
                if(null != queryKey)
                    response = response.replace(entryVal,
                            null != queryParams.get(queryKey)
                            ? queryParams.get(queryKey)[0]
                            : getDefaultVal(entryVal));
                if(null != pathKey & null != pathParams.get(pathKey))
                    response = response.replace(entryVal,
                            null != pathParams.get(pathKey)
                            ? pathParams.get(pathKey)
                            : getDefaultVal(entryVal));
                if(null != bodyKey ){
                    ArrayNode bodyJson = readJSONArray(requestBody, bodyKey);
                    if( null != bodyJson){
                        JsonNode bodyElement = bodyJson.get(0);
                        response = response.replace("\""+entryVal+"\"", bodyElement.toString());
                    }else{
                        response = response.replace(entryVal, getDefaultVal(entryVal));
                    }

                }
            }
            return response;
        }else{
            return "";
        }
    }
    private String getEntrySearchKey(String source, String key){
        return source.startsWith(key)
                ? source.substring(key.length(),source.contains("::") ? source.indexOf("::") : source.length())
                : null;
    }
    private String getDefaultVal(String source){
        return source.substring(source.contains("::") ? source.indexOf("::")+2 : 0 );
    }

    private JsonNode readResponse(ArrayNode arrayNode, String apiPath, String mockData){
        var jsonNodeIterator = arrayNode.get(0).elements();
        var arrayNodeSize = arrayNode.get(0).size();
        var key = apiPath + mockData;
        var responseCnt = 0;
        while(jsonNodeIterator.hasNext()) {
            JsonNode jsonVal = jsonNodeIterator.next();
            if(!REQUEST_CACHE.containsKey(key)){
                REQUEST_CACHE.put(key,++responseCnt);
                return jsonVal;
            }else if(REQUEST_CACHE.get(key) == responseCnt ){
                REQUEST_CACHE.put(key,++responseCnt);
                if(responseCnt == arrayNodeSize)
                    REQUEST_CACHE.remove(key);
                return jsonVal;
            }
            responseCnt++;
         }
        throw new HttpClientErrorException(HttpStatus.NOT_FOUND, "Failed to read from Response Loop");
    }

    private LinkedHashMap readJsonPath(String json, String pathExp){
        try{
           return JsonPath.parse(json).read(pathExp);
        }catch (PathNotFoundException ex){
            return null;
        }
    }

    private ArrayNode readJSONArray(String json, String pathExp){
        try{
            var conf = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
                    .options(Option.ALWAYS_RETURN_LIST).build();
            return JsonPath.using(conf).parse(json).read(pathExp);
        }catch (Exception ex){
            return null;
        }
    }

    private String pathResolve(String requestUrl, LinkedHashMap<String, String> pathParams, LinkedHashMap<String, String> requestPathParams ){
        for(Map.Entry<String, String> path: pathParams.entrySet()){
            if(path.getValue().equals("*") && !requestPathParams.isEmpty() && requestPathParams.get(path.getKey()) != null){
                requestUrl = requestUrl.replace("{"+path.getKey()+"}", requestPathParams.get(path.getKey()));
            }else{
                requestUrl = requestUrl.replace("{"+path.getKey()+"}", path.getValue());
            }
        }
        return requestUrl;
    }

    private String mapToString( Map<String, String[]> parameterMap){
        return parameterMap.keySet().stream()
                .map(key -> key + "=" + Arrays.toString(parameterMap.get(key)))
                .collect(Collectors.joining(", ", "{", "}"));
    }
}
