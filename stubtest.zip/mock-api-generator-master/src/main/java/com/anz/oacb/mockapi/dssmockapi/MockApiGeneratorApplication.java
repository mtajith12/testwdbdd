package com.anz.oacb.mockapi.dssmockapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockApiGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(MockApiGeneratorApplication.class, args);
    }

}
